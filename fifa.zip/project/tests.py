from django.test import TestCase
from django.utils import timezone
from tournament.models import Tournament, Team, Match, Result
from tournament.group_stage import GroupStageManager, MatchStatus

class GroupStageManagerTest(TestCase):
	def setUp(self):
		self.tournament = Tournament.objects.create(
			name="Test Tournament",
			number_of_groups=2,
			teams_per_group=2,
			start_date=timezone.now()
		)
		# Create teams
		self.team_a = Team.objects.create(name="Team A", tournament=self.tournament)
		self.team_b = Team.objects.create(name="Team B", tournament=self.tournament)
		self.team_c = Team.objects.create(name="Team C", tournament=self.tournament)
		self.team_d = Team.objects.create(name="Team D", tournament=self.tournament)
		
		self.manager = GroupStageManager(self.tournament)

	def test_create_group_matches(self):
		self.manager.create_group_matches()
		self.assertEqual(Match.objects.count(), 2 * 1 + 2 * 1)  # each group has 2 teams, 1 match per group

	def test_process_result_pending(self):
		self.manager.create_group_matches()
		match = Match.objects.first()
		result_team_a = Result.objects.create(match=match, team=match.team1, score=1, opponent_score=0)
		status = self.manager.process_result(result_team_a)
		self.assertEqual(status, MatchStatus.PENDING)

	def test_process_result_confirmed(self):
		self.manager.create_group_matches()
		match = Match.objects.first()
		result_team_a = Result.objects.create(match=match, team=match.team1, score=1, opponent_score=0)
		result_team_b = Result.objects.create(match=match, team=match.team2, score=0, opponent_score=1)
		status = self.manager.process_result(result_team_a)
		self.assertEqual(status, MatchStatus.CONFIRMED)
		match.refresh_from_db()
		self.assertTrue(match.confirmed)

	def test_check_group_completion(self):
		self.manager.create_group_matches()
		# None confirmed, should return False
		self.assertFalse(self.manager.check_group_completion())
		# Confirm all matches
		for m in Match.objects.all():
			m.confirmed = True
			m.save()
		self.assertTrue(self.manager.check_group_completion())

	def test_get_group_standings(self):
		self.manager.create_group_matches()
		match = Match.objects.first()
		# Team A beats Team B
		Result.objects.create(match=match, team=match.team1, score=2, opponent_score=1, confirmed=True)
		Result.objects.create(match=match, team=match.team2, score=1, opponent_score=2, confirmed=True)
		match.confirmed = True
		match.save()
		standings = self.manager.get_group_standings("A")
		self.assertEqual(len(standings), 2)
		self.assertEqual(standings[0]['team'], self.team_a)