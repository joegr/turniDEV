from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
from .models import Tournament, Team, Match, Result
from .services.tournament import TournamentService

class TournamentTestCase(TestCase):
    def setUp(self):
        # Create users
        self.user1 = User.objects.create_user('manager1', 'manager1@test.com', 'password123')
        self.user2 = User.objects.create_user('manager2', 'manager2@test.com', 'password123')
        
        # Create tournament
        self.tournament = Tournament.objects.create(
            name="Test Tournament",
            datetime=timezone.now() + timedelta(days=30),
            number_of_groups=2,
            teams_per_group=4,
            is_active=True
        )
        
        # Create teams
        self.team1 = Team.objects.create(
            name="Team 1",
            manager=self.user1,
            tournament=self.tournament,
            registration_code=TournamentService.generate_registration_code()
        )
        self.team2 = Team.objects.create(
            name="Team 2",
            manager=self.user2,
            tournament=self.tournament,
            registration_code=TournamentService.generate_registration_code()
        )

    def test_team_registration(self):
        """Test team registration process"""
        # Test initial state
        self.assertEqual(self.team1.player_count, 0)
        self.assertFalse(self.team1.registration_complete)
        
        # Add players
        for _ in range(8):
            self.team1.update_player_count(increment=True)
        
        # Check registration complete
        self.assertEqual(self.team1.player_count, 8)
        self.assertTrue(self.team1.registration_complete)
        
        # Test maximum players
        with self.assertRaises(ValueError):
            for _ in range(7):  # Try to add 7 more (would exceed 14)
                self.team1.update_player_count(increment=True)

    def test_match_result_submission(self):
        """Test match result submission and verification"""
        match = Match.objects.create(
            tournament=self.tournament,
            team_home=self.team1,
            team_away=self.team2,
            match_date=timezone.now() + timedelta(days=1),
            stage='GROUP'
        )
        
        # Submit result from team 1
        result1 = TournamentService.process_match_result(
            match=match,
            submitting_team=self.team1,
            our_score=2,
            opponent_score=1
        )
        
        # Check match status after first submission
        match.refresh_from_db()
        self.assertEqual(match.status, 'SCHEDULED')
        
        # Submit matching result from team 2
        result2 = TournamentService.process_match_result(
            match=match,
            submitting_team=self.team2,
            our_score=1,
            opponent_score=2
        )
        
        # Check match status after both submissions
        match.refresh_from_db()
        self.assertEqual(match.status, 'CONFIRMED')
        self.assertEqual(match.home_score, 2)
        self.assertEqual(match.away_score, 1)

    def test_tournament_standings(self):
        """Test tournament standings calculation"""
        # Create and confirm a match
        match = Match.objects.create(
            tournament=self.tournament,
            team_home=self.team1,
            team_away=self.team2,
            match_date=timezone.now(),
            stage='GROUP',
            status='CONFIRMED',
            home_score=2,
            away_score=1
        )
        
        standings = TournamentService.get_tournament_standings(self.tournament)
        
        # Check team1 stats (winner)
        team1_stats = next(s for s in standings if s['team'] == self.team1)
        self.assertEqual(team1_stats['matches_played'], 1)
        self.assertEqual(team1_stats['wins'], 1)
        self.assertEqual(team1_stats['points'], 3)
        self.assertEqual(team1_stats['goals_for'], 2)
        self.assertEqual(team1_stats['goals_against'], 1)
        
        # Check team2 stats (loser)
        team2_stats = next(s for s in standings if s['team'] == self.team2)
        self.assertEqual(team2_stats['matches_played'], 1)
        self.assertEqual(team2_stats['losses'], 1)
        self.assertEqual(team2_stats['points'], 0)
        self.assertEqual(team2_stats['goals_for'], 1)
        self.assertEqual(team2_stats['goals_against'], 2)

    def test_disputed_results(self):
        """Test handling of disputed match results"""
        match = Match.objects.create(
            tournament=self.tournament,
            team_home=self.team1,
            team_away=self.team2,
            match_date=timezone.now(),
            stage='GROUP'
        )
        
        # Submit conflicting results
        TournamentService.process_match_result(
            match=match,
            submitting_team=self.team1,
            our_score=2,
            opponent_score=1
        )
        
        TournamentService.process_match_result(
            match=match,
            submitting_team=self.team2,
            our_score=2,
            opponent_score=0  # Different score
        )
        
        match.refresh_from_db()
        self.assertEqual(match.status, 'DISPUTED')

    def test_tournament_completion(self):
        """Test tournament completion detection"""
        # Create and confirm final match
        final = Match.objects.create(
            tournament=self.tournament,
            team_home=self.team1,
            team_away=self.team2,
            match_date=timezone.now(),
            stage='FINAL',
            status='CONFIRMED',
            home_score=3,
            away_score=2
        )
        
        self.tournament.status = 'KNOCKOUT'
        self.tournament.save()
        
        is_complete = TournamentService.check_tournament_completion(self.tournament)
        self.assertTrue(is_complete)
        
        self.tournament.refresh_from_db()
        self.assertEqual(self.tournament.status, 'COMPLETED')
