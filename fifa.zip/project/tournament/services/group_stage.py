from typing import List, Dict
from django.db.models import Count, Q
import random
from datetime import timedelta
from ..models import Tournament, Team, Match

class GroupStageService:
    def __init__(self, tournament: Tournament):
        self.tournament = tournament
        self.teams = list(Team.objects.filter(
            tournament=tournament,
            registration_status='FINALIZED'
        ))

    def generate_groups(self) -> Dict[int, List[Team]]:
        if len(self.teams) != self.tournament.num_groups * self.tournament.teams_per_group:
            raise ValueError("Incorrect number of teams for group stage")

        random.shuffle(self.teams)
        self.groups = {}
        
        for i in range(self.tournament.num_groups):
            start_idx = i * self.tournament.teams_per_group
            end_idx = start_idx + self.tournament.teams_per_group
            self.groups[i] = self.teams[start_idx:end_idx]

        return self.groups

    def generate_matches(self) -> List[Match]:
        matches = []
        base_date = self.tournament.start_date
        match_day = 0

        for group_num, teams in self.groups.items():
            # Round-robin format
            for i in range(len(teams)):
                for j in range(i + 1, len(teams)):
                    match = Match.objects.create(
                        tournament=self.tournament,
                        team_home=teams[i],
                        team_away=teams[j],
                        match_date=base_date + timedelta(days=match_day),
                        stage='GROUP'
                    )
                    matches.append(match)
                    match_day += 1

        return matches

    def get_group_standings(self) -> Dict[int, List[Dict]]:
        standings = {}
        
        for group_num, teams in self.groups.items():
            team_stats = []
            for team in teams:
                stats = {
                    'team': team,
                    'points': 0,
                    'goals_for': 0,
                    'goals_against': 0,
                    'goal_difference': 0
                }
                
                # Home matches
                home_matches = Match.objects.filter(
                    tournament=self.tournament,
                    team_home=team,
                    stage='GROUP',
                    status='CONFIRMED'
                )
                for match in home_matches:
                    stats['goals_for'] += match.home_score or 0
                    stats['goals_against'] += match.away_score or 0
                    if match.home_score > match.away_score:
                        stats['points'] += 3
                    elif match.home_score == match.away_score:
                        stats['points'] += 1

                # Away matches
                away_matches = Match.objects.filter(
                    tournament=self.tournament,
                    team_away=team,
                    stage='GROUP',
                    status='CONFIRMED'
                )
                for match in away_matches:
                    stats['goals_for'] += match.away_score or 0
                    stats['goals_against'] += match.home_score or 0
                    if match.away_score > match.home_score:
                        stats['points'] += 3
                    elif match.away_score == match.home_score:
                        stats['points'] += 1

                stats['goal_difference'] = stats['goals_for'] - stats['goals_against']
                team_stats.append(stats)

            # Sort by points, then goal difference, then goals scored
            team_stats.sort(
                key=lambda x: (-x['points'], -x['goal_difference'], -x['goals_for'])
            )
            standings[group_num] = team_stats 