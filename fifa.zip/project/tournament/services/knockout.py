from typing import List, Dict
from django.db.models import Q
from datetime import timedelta
from ..models import Tournament, Team, Match
from .group_stage import GroupStageService

class KnockoutService:
    def __init__(self, tournament: Tournament):
        self.tournament = tournament
        self.group_service = GroupStageService(tournament)

    def get_qualified_teams(self) -> List[Team]:
        standings = self.group_service.get_group_standings()
        qualified_teams = []
        
        # Get top 2 teams from each group
        for group_standings in standings.values():
            qualified_teams.extend([
                stats['team'] for stats in group_standings[:2]
            ])
        
        return qualified_teams

    def generate_round_of_16(self) -> List[Match]:
        qualified_teams = self.get_qualified_teams()
        if len(qualified_teams) != 16:
            raise ValueError("Need exactly 16 teams for Round of 16")

        # Pair teams from different groups
        matches = []
        base_date = max(
            Match.objects.filter(tournament=self.tournament).values_list('match_date', flat=True)
        ) + timedelta(days=3)

        # Standard Champions League format pairing
        group_winners = qualified_teams[::2]
        group_runners = qualified_teams[1::2]
        
        for i, (winner, runner) in enumerate(zip(group_winners, group_runners)):
            match = Match.objects.create(
                tournament=self.tournament,
                team_home=winner,
                team_away=runner,
                match_date=base_date + timedelta(days=i),
                stage='RO16'
            )
            matches.append(match)

        return matches

    def advance_knockout_stage(self) -> List[Match]:
        current_stage = self._get_current_stage()
        if not current_stage:
            raise ValueError("No active knockout stage found")

        winners = self._get_stage_winners(current_stage)
        next_stage = self._get_next_stage(current_stage)
        
        if not next_stage:
            if current_stage == 'FINAL':
                self.tournament.status = 'COMPLETED'
                self.tournament.save()
                return []
            raise ValueError("Invalid stage progression")

        matches = []
        base_date = max(
            Match.objects.filter(
                tournament=self.tournament,
                stage=current_stage
            ).values_list('match_date', flat=True)
        ) + timedelta(days=3)

        # Create matches for next round
        for i in range(0, len(winners), 2):
            match = Match.objects.create(
                tournament=self.tournament,
                team_home=winners[i],
                team_away=winners[i+1],
                match_date=base_date + timedelta(days=i//2),
                stage=next_stage
            )
            matches.append(match)

        return matches

    def _get_current_stage(self) -> str:
        stages = ['RO16', 'QUARTER', 'SEMI', 'FINAL']
        for stage in stages:
            if Match.objects.filter(
                tournament=self.tournament,
                stage=stage,
                status__in=['SCHEDULED', 'PENDING']
            ).exists():
                return stage
        return None

    def _get_next_stage(self, current_stage: str) -> str:
        stages = {
            'RO16': 'QUARTER',
            'QUARTER': 'SEMI',
            'SEMI': 'FINAL',
            'FINAL': None
        }
        return stages.get(current_stage)

    def _get_stage_winners(self, stage: str) -> List[Team]:
        matches = Match.objects.filter(
            tournament=self.tournament,
            stage=stage,
            status='CONFIRMED'
        )
        
        winners = []
        for match in matches:
            if match.home_score > match.away_score:
                winners.append(match.team_home)
            elif match.away_score > match.home_score:
                winners.append(match.team_away)
            elif match.penalties:
                # In case of penalties, assume the home team won
                # (this should be extended with a penalties_winner field)
                winners.append(match.team_home)
                
        return winners 