from rest_framework import serializers
from .models import Tournament, Team, Match, Result
from rest_framework.exceptions import ValidationError

class TournamentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tournament
        fields = '__all__'

class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = '__all__'

class MatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Match
        fields = '__all__'

class ResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = Result
        fields = ['match', 'home_score', 'away_score', 'extra_time', 'penalties']
        
    def validate(self, data):
        match = data['match']
        submitting_team = self.context['request'].user.team_set.first()
        
        if not submitting_team:
            raise ValidationError("User must be associated with a team")
            
        if submitting_team not in [match.team_home, match.team_away]:
            raise ValidationError("Team must be part of the match")
            
        if Result.objects.filter(match=match, submitting_team=submitting_team).exists():
            raise ValidationError("Result already submitted for this match")
            
        return data

class MatchResultSerializer(serializers.Serializer):
    our_score = serializers.IntegerField(min_value=0)
    opponent_score = serializers.IntegerField(min_value=0)
    extra_time = serializers.BooleanField(default=False)
    penalties = serializers.BooleanField(default=False)

    def validate(self, data):
        if data['penalties'] and not data['extra_time']:
            raise serializers.ValidationError("Penalties can only occur after extra time")
        return data