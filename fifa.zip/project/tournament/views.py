from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.generic import CreateView, TemplateView, DetailView, ListView
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Count
from .models import Tournament, Team, Match, Result
from .serializers import (
    TournamentSerializer,
    TeamSerializer,
    MatchSerializer,
    MatchResultSerializer,
    ResultSerializer
)
from .services.group_stage import GroupStageService
from .services.knockout import KnockoutService
from .tasks import validate_team_registration
from .services.tournament import TournamentService
from django.shortcuts import get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseForbidden
from django.contrib import messages
from django.urls import reverse
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django.db import models
from django.contrib.auth.views import LoginView

class SignUpView(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'

@method_decorator(login_required, name='dispatch')
class TournamentAdminView(TemplateView):
    template_name = 'tournament/admin.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['tournaments'] = Tournament.objects.all()
        context['pending_teams'] = Team.objects.filter(
            player_count__lt=8
        )
        context['pending_results'] = Match.objects.filter(
            status='PENDING'
        )
        return context

class TournamentViewSet(viewsets.ModelViewSet):

    queryset = Tournament.objects.all()
    serializer_class = TournamentSerializer
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        if self.action in ['create', 'update', 'destroy']:
            return [IsAdminUser()]
        return super().get_permissions()

    @action(detail=True, methods=['post'])
    def start_group_stage(self, request, pk=None):
        tournament = self.get_object()
        if tournament.status != 'REGISTRATION':
            return Response(
                {"error": "Tournament must be in registration status"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        group_service = GroupStageService(tournament)
        try:
            group_service.generate_groups()
            group_service.generate_matches()
            tournament.status = 'GROUP_STAGE'
            tournament.save()
            return Response({"status": "Group stage started"})
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=True, methods=['post'])
    def start_knockout_stage(self, request, pk=None):
        tournament = self.get_object()
        if tournament.status != 'GROUP_STAGE':
            return Response(
                {"error": "Tournament must be in group stage"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        knockout_service = KnockoutService(tournament)
        try:
            knockout_service.generate_round_of_16()
            tournament.status = 'KNOCKOUT'
            tournament.save()
            return Response({"status": "Knockout stage started"})
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=True, methods=['get'])
    def group_info(self, request, pk=None):
        tournament = self.get_object()
        if tournament.status not in ['GROUP_STAGE', 'KNOCKOUT']:
            return Response(
                {"error": "Tournament is not in or past group stage"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        group_service = GroupStageService(tournament)
        standings = group_service.get_group_standings()
        
        return Response({
            "standings": standings,
            "groups": {
                group_num: [team.id for team in teams] 
                for group_num, teams in group_service.groups.items()
            }
        })

class TeamViewSet(viewsets.ModelViewSet):
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Team.objects.filter(manager=self.request.user)

    def perform_create(self, serializer):
        if Team.objects.filter(manager=self.request.user).exists():
            raise serializers.ValidationError("You already have a team")
        serializer.save(manager=self.request.user)

    @action(detail=True, methods=['post'])
    def complete_registration(self, request, pk=None):
        team = self.get_object()
        task = validate_team_registration.delay(team.id)
        return Response({'task_id': task.id})

class MatchViewSet(viewsets.ModelViewSet):
    queryset = Match.objects.all()
    serializer_class = MatchSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()

    @action(detail=True, methods=['post'])
    def submit_result(self, request, pk=None):
        match = self.get_object()
        serializer = MatchResultSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        team = request.user.team_set.first()
        if not team or team not in [match.team_home, match.team_away]:
            return Response(
                {"error": "Not authorized to submit result"},
                status=status.HTTP_403_FORBIDDEN
            )

        TournamentService.process_match_result(
            match=match,
            submitting_team=team,
            **serializer.validated_data
        )
        return Response({"status": "Result submitted"})

class ResultViewSet(viewsets.ModelViewSet):
    queryset = Result.objects.all()
    serializer_class = ResultSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(submitting_team=self.request.user.team_set.first())

    @action(detail=True, methods=['post'])
    def confirm_result(self, request, pk=None):
        result = self.get_object()
        if result.submitting_team == request.user.team_set.first():
            return Response(
                {"error": "Cannot confirm your own result submission"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        result.confirmed = True
        result.save()
        
        # Update match status if both teams have confirmed results
        match = result.match
        if match.results.filter(confirmed=True).count() == 2:
            match.status = 'CONFIRMED'
            match.save()
        
        return Response({"status": "Result confirmed"})

class ManagerDashboardView(LoginRequiredMixin, ListView):
    template_name = 'tournament/manager_dashboard.html'
    context_object_name = 'teams'

    def get_queryset(self):
        return Team.objects.filter(manager=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user_teams = self.get_queryset()

        context['upcoming_matches'] = Match.objects.filter(
            status='SCHEDULED'
        ).filter(
            models.Q(team_home__in=user_teams) | 
            models.Q(team_away__in=user_teams)
        ).order_by('match_date')

        context['pending_results'] = Match.objects.filter(
            status='PENDING'
        ).filter(
            models.Q(team_home__in=user_teams) | 
            models.Q(team_away__in=user_teams)
        )

        context['recent_matches'] = Match.objects.filter(
            status='CONFIRMED'
        ).filter(
            models.Q(team_home__in=user_teams) | 
            models.Q(team_away__in=user_teams)
        ).order_by('-match_date')[:5]

        return context

class TeamDetailView(LoginRequiredMixin, DetailView):
    model = Team
    template_name = 'tournament/team_detail.html'
    context_object_name = 'team'

    def get_queryset(self):
        return Team.objects.filter(manager=self.request.user)

class MatchResultSubmissionView(LoginRequiredMixin, DetailView):
    model = Match
    template_name = 'tournament/submit_result.html'
    context_object_name = 'match'

    def post(self, request, *args, **kwargs):
        match = self.get_object()
        team = request.user.team_set.first()

        if not team or team not in [match.team_home, match.team_away]:
            return HttpResponseForbidden("Not authorized to submit result for this match")

        try:
            result = TournamentService.process_match_result(
                match=match,
                submitting_team=team,
                our_score=int(request.POST.get('our_score')),
                opponent_score=int(request.POST.get('opponent_score')),
                extra_time=bool(request.POST.get('extra_time')),
                penalties=bool(request.POST.get('penalties'))
            )
            messages.success(request, "Result submitted successfully")
            return redirect('manager_dashboard')
        except ValueError as e:
            messages.error(request, str(e))
            return self.get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        team = self.request.user.team_set.first()
        match = self.get_object()
        
        # Determine if the user's team is home or away
        context['is_home_team'] = team == match.team_home
        context['our_team'] = team
        context['opponent_team'] = match.team_away if context['is_home_team'] else match.team_home
        
        return context

class MatchResultConfirmationView(LoginRequiredMixin, DetailView):
    model = Match
    template_name = 'tournament/confirm_result.html'
    context_object_name = 'match'

    def post(self, request, *args, **kwargs):
        match = self.get_object()
        team = request.user.team_set.first()

        if not team or team not in [match.team_home, match.team_away]:
            return HttpResponseForbidden("Not authorized to confirm result for this match")

        result = get_object_or_404(Result, match=match, submitting_team=team)
        
        try:
            result.confirmed = True
            result.save()

            # Check if both teams have confirmed
            if match.results.filter(confirmed=True).count() == 2:
                match.status = 'CONFIRMED'
                match.save()
                messages.success(request, "Match result confirmed")
            else:
                messages.info(request, "Result confirmed. Waiting for opponent confirmation")
            
            return redirect('manager_dashboard')
        except Exception as e:
            messages.error(request, f"Error confirming result: {str(e)}")
            return self.get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        match = self.get_object()
        team = self.request.user.team_set.first()
        
        context['result'] = get_object_or_404(
            Result,
            match=match,
            submitting_team__in=[match.team_home, match.team_away]
        )
        context['is_home_team'] = team == match.team_home
        
        return context

class TournamentStandingsView(LoginRequiredMixin, DetailView):
    model = Tournament
    template_name = 'tournament/standings.html'
    context_object_name = 'tournament'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tournament = self.get_object()
        
        # Get all teams for this tournament
        context['teams'] = Team.objects.filter(
            tournament=tournament
        ).order_by('-registration_complete', '-player_count')
        
        return context

class TournamentBracketView(DetailView):
    model = Tournament
    template_name = 'tournament/tournament_bracket.html'
    context_object_name = 'tournament'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tournament = self.get_object()

        # Get matches organized by stage
        context['group_matches'] = Match.objects.filter(
            tournament=tournament,
            stage='GROUP'
        ).order_by('match_date')

        context['ro16_matches'] = Match.objects.filter(
            tournament=tournament,
            stage='RO16'
        ).order_by('match_date')

        context['quarter_matches'] = Match.objects.filter(
            tournament=tournament,
            stage='QUARTER'
        ).order_by('match_date')

        context['semi_matches'] = Match.objects.filter(
            tournament=tournament,
            stage='SEMI'
        ).order_by('match_date')

        context['final_match'] = Match.objects.filter(
            tournament=tournament,
            stage='FINAL'
        ).first()

        return context

class GroupStageView(LoginRequiredMixin, DetailView):
    model = Tournament
    template_name = 'tournament/group_stage.html'
    context_object_name = 'tournament'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tournament = self.get_object()
        
        if tournament.status != 'GROUP_STAGE':
            messages.error(self.request, "Tournament is not in group stage")
            return context
            
        group_service = GroupStageService(tournament)
        
        try:
            # First check if there are any group stage matches
            if not Match.objects.filter(tournament=tournament, stage='GROUP').exists():
                messages.warning(self.request, "Groups have not been generated yet")
                context['groups_not_generated'] = True
                return context
                
            context['standings'] = group_service.get_group_standings()
            
            # Get all group stage matches organized by group
            group_matches = {}
            matches = Match.objects.filter(
                tournament=tournament,
                stage='GROUP'
            ).select_related('team_home', 'team_away').order_by('match_date')
            
            for match in matches:
                # Determine which group this match belongs to
                for group_num, teams in group_service.groups.items():
                    if match.team_home in teams and match.team_away in teams:
                        if group_num not in group_matches:
                            group_matches[group_num] = []
                        group_matches[group_num].append(match)
                        break
                        
            context['group_matches'] = group_matches
            
        except Exception as e:
            messages.error(self.request, f"Error loading group stage: {str(e)}")
            context['error'] = str(e)
            
        return context

class UserDashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'tournament/user_dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Get teams managed by the user
        context['managed_teams'] = Team.objects.filter(manager=user)
        
        # Get upcoming matches for user's teams
        user_teams = Team.objects.filter(manager=user)
        context['upcoming_matches'] = Match.objects.filter(
            models.Q(team_home__in=user_teams) | 
            models.Q(team_away__in=user_teams),
            status='SCHEDULED'
        ).order_by('match_date')
        
        # Get active tournaments
        context['active_tournaments'] = Tournament.objects.filter(
            is_active=True
        ).order_by('datetime')
        
        return context

class CustomLoginView(LoginView):
    template_name = 'registration/login.html'
    
    def get_success_url(self):
        # Check if user has a team
        if self.request.user.team_set.exists():
            team = self.request.user.team_set.first()
            return reverse('team_detail', kwargs={'pk': team.pk})
        return reverse('manager_dashboard')