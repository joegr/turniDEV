from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator

class Manager(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    psn_id = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.user.username} ({self.psn_id})"

class Tournament(models.Model):
    name = models.CharField(max_length=255)
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    datetime = models.DateTimeField()
    number_of_groups = models.IntegerField()
    teams_per_group = models.IntegerField()
    is_active = models.BooleanField(default=True)
    status = models.CharField(
        max_length=20,
        choices=[
            ('REGISTRATION', 'Registration'),
            ('GROUP_STAGE', 'Group Stage'),
            ('KNOCKOUT', 'Knockout Stage'),
            ('COMPLETED', 'Completed')
        ],
        default='REGISTRATION'
    )

    def clean(self):
        if self.number_of_groups * self.teams_per_group < 2:
            raise ValidationError("Tournament must have at least 2 teams")

    def __str__(self):
        return self.name

class Team(models.Model):
    name = models.CharField(max_length=255)
    manager = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    player_count = models.IntegerField(
        default=0,
        validators=[
            MinValueValidator(0),
            MaxValueValidator(14)
        ]
    )
    registration_complete = models.BooleanField(default=False)

    def clean(self):
        super().clean()
        if self.player_count < 0:
            raise ValidationError({"player_count": "Player count cannot be negative"})
        if self.player_count > 14:
            raise ValidationError({"player_count": "Team cannot have more than 14 players"})

    def update_player_count(self, increment=True):
        """
        Update player count and registration status.
        increment=True adds a player, False removes a player
        Returns True if update was successful, False otherwise.
        """
        new_count = self.player_count + (1 if increment else -1)
        
        # Validate new count
        if new_count < 0:
            raise ValueError("Cannot remove player: Team has no players")
        if new_count > 14:
            raise ValueError("Cannot add player: Team already has maximum players (14)")
            
        # Update count and status
        self.player_count = new_count
        self.registration_complete = 8 <= new_count <= 14
        self.save()

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.player_count} players)"

class Match(models.Model):
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    team_home = models.ForeignKey(Team, related_name='home_matches', on_delete=models.CASCADE, blank=True, null=True)
    team_away = models.ForeignKey(Team, related_name='away_matches', on_delete=models.CASCADE, blank=True, null=True)
    match_date = models.DateField()
    home_score = models.IntegerField(null=True, blank=True)
    away_score = models.IntegerField(null=True, blank=True)
    stage = models.CharField(
        max_length=20,
        choices=[
            ('GROUP', 'Group Stage'),
            ('RO16', 'Round of 16'),
            ('QUARTER', 'Quarter Final'),
            ('SEMI', 'Semi Final'),
            ('FINAL', 'Final')
        ],
        default='GROUP',
    )
    status = models.CharField(
        max_length=20,
        choices=[
            ('SCHEDULED', 'Scheduled'),
            ('PENDING', 'Pending Confirmation'),
            ('CONFIRMED', 'Confirmed'),
            ('DISPUTED', 'Disputed')
        ],
        default='SCHEDULED'
    )
    extra_time = models.BooleanField(default=False)
    penalties = models.BooleanField(default=False)

    def clean(self):
        if self.team_home == self.team_away:
            raise ValidationError("A team cannot play against itself")
        if self.team_home.tournament != self.tournament or self.team_away.tournament != self.tournament:
            raise ValidationError("Teams must belong to this tournament")

    def __str__(self):
        return f"{self.team_home} vs {self.team_away}"

class Result(models.Model):
    match = models.OneToOneField(Match, on_delete=models.CASCADE, related_name='results')
    submitting_team = models.ForeignKey(Team, on_delete=models.CASCADE)
    home_score = models.IntegerField()
    away_score = models.IntegerField()
    submitted_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['match', 'submitting_team']

    def __str__(self):
        return f"{self.match} - {self.submitting_team} submission"